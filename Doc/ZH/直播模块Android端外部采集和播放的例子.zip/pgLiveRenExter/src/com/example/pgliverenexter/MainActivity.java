package com.example.pgliverenexter;


import java.nio.ByteBuffer;

import javax.microedition.khronos.opengles.GL10;

import com.peergine.android.live.pgLibLive;
import com.peergine.android.live.pgLibLiveMode;
import com.peergine.plugin.android.pgDevVideoOut;
import com.peergine.plugin.lib.pgLibJNINode;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends Activity {

	private android.widget.EditText m_editDevID;
	private android.widget.Button m_btnStart;
	private android.widget.Button m_btnStop;
	private android.widget.Button m_btnCamera;
	private android.widget.Button m_btnScan;
	private android.widget.Button m_btnWhole;
	private android.widget.Button m_btnCut;
	public static android.widget.TextView m_sDebug;

	String m_sDevID = "";
	pgLibLive m_Live = new pgLibLive();
	LinearLayout m_View = null;
	SurfaceView m_Wnd = null;
	VideoPlayView m_wndPlay = null;
	
	private pgLibLive.OnEventListener m_OnEvent = new pgLibLive.OnEventListener() {

		@Override
		public void event(String sAct, String sData, String  sRender) {
			// TODO Auto-generated method stub

			if (sAct.equals("VideoStatus")) {
				// Video status report
			}
			else if (sAct.equals("Notify")) {
				// Receive the notify from capture side
				String sInfo = "Receive notify: data=" + sData;
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();			
			}
			else if (sAct.equals("RenderJoin")) {
				// A render join
				String sInfo = "Render join: render=" + sRender;
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();			
			}
			else if (sAct.equals("RenderLeave")) {
				// A render leave
				String sInfo = "Render leave: render=" + sRender;
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();			
			}
			else if (sAct.equals("Message")) {
				// Receive the message from render or capture
				String sInfo = "Receive msg: data=" + sData + ", render=" + sRender;
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();			
			}
			else if (sAct.equals("Login")) {
				// Login reply
				if (sData.equals("0")) {
					String sInfo = "Login success";
					Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
				}
				else {
					String sInfo = "Login failed, error=" + sData;
					Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();					
				}
			}
			else if (sAct.equals("Logout")) {
				// Logout
				String sInfo = "Logout";
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
			}
			else if (sAct.equals("Connect")) {
				// Connect to capture
				String sInfo = "Connect to capture";
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
			}
			else if (sAct.equals("Disconnect")) {
				// Disconnect from capture
				String sInfo = "Diconnect from capture";
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
			}
			else if (sAct.equals("Offline")) {
				// The capture is offline.
				String sInfo = "Capture offline";
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
			}
			else if (sAct.equals("LanScanResult")) {
				// Lan scan result.
				String sInfo = "Lan scan result: " + sData;
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
				m_sDebug.setText(sData);
			}
			else if (sAct.equals("ForwardAllocReply")) {
				String sInfo = "Forward alloc relpy: error=" + sData;
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
			}
			else if (sAct.equals("ForwardFreeReply")) {
				String sInfo = "Forward free relpy: error=" + sData;
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
			} 
			else if (sAct.equals("VideoCamera")) {
				String sInfo = "The picture is save to: " + sData;
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
			}
			else if (sAct.equals("SvrNotify")) {
				String sInfo = "Receive server notify: " + sData;
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
			}
			
			Log.d("pgLiveRender", "OnEvent: Act=" + sAct + ", Data=" + sData
					+ ", Render=" + sRender);
		}
	};
	
	private boolean CheckPlugin() {
		if (pgLibJNINode.Initialize(this)) {
			pgLibJNINode.Clean();
			return true;
		}
		else {
			Alert("Error", "Please import 'pgPluginLib' peergine middle ware!");
			return false;
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
				WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

		m_editDevID = (android.widget.EditText) findViewById(R.id.editDevID);
		m_btnStart = (android.widget.Button) findViewById(R.id.btnStart);
		m_btnStart.setOnClickListener(m_OnClink);
		m_btnStop = (android.widget.Button) findViewById(R.id.btnStop);
		m_btnStop.setOnClickListener(m_OnClink);
		m_btnCamera = (android.widget.Button) findViewById(R.id.btnCamera);
		m_btnCamera.setOnClickListener(m_OnClink);
		m_btnScan = (android.widget.Button)findViewById(R.id.btnScan);
		m_btnScan.setOnClickListener(m_OnClink);
		m_btnWhole = (android.widget.Button) findViewById(R.id.btnViewWhole);
		m_btnWhole.setOnClickListener(m_OnClink);
		m_btnCut = (android.widget.Button)findViewById(R.id.btnViewCut);
		m_btnCut.setOnClickListener(m_OnClink);
		m_sDebug = (android.widget.TextView)findViewById(R.id.debug);

		if (!CheckPlugin()) {
			return;
		}

		if (!m_Live.Initialize(pgLibLiveMode.Render, "ANDROID_DEMO", "1234",
			"connect.peergine.com:7781", "", 3, "(OutputExternal){1}(MaxStream){0}", this))
		{
			Log.d("pgLiveRanExter", "LiveStart: Live.Initialize failed!");
			Alert("Error", "Network error, DNS Resolution failed!");
       		android.os.Process.killProcess(android.os.Process.myPid());  
			return;
		}
		
		m_Wnd = (SurfaceView)m_Live.WndCreate(0, 0, 40, 30);
		m_Live.SetEventListener(m_OnEvent);

		pgDevVideoOut.SetCallback(m_oVideoOutCB);
		Log.d("pgLiveRanExter", "pgDevVideoOut Set callback");

		m_View = (LinearLayout)findViewById(R.id.layoutVideo);
		m_wndPlay = new VideoPlayView(this);
		m_View.addView(m_wndPlay);
		m_wndPlay.setVisibility(View.VISIBLE);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
    protected void onPause() {
        super.onPause();
    //    m_wndPlay.onPause();
    }
 
    @Override
    protected void onResume() {
        super.onResume();
    //   m_wndPlay.onResume();
    }
    
    @Override
    protected void onDestroy() {
		super.onDestroy();

		LiveStop();
	}

	public boolean onKeyUp(int keyCode, KeyEvent event) {
	    if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			Log.d("pgLiveCapture", "onKeyDown, KEYCODE_BACK");
	      	ExitDialog();
      		return true;
	    }
	    return super.onKeyUp(keyCode, event);
	}

	private DialogInterface.OnClickListener m_DlgClick = new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int which) {
        	if (which == AlertDialog.BUTTON_POSITIVE) {
        		LiveStop();
        		android.os.Process.killProcess(android.os.Process.myPid());  
        	}
        }
    };
	public void ExitDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);  
        builder.setTitle("Confirm");  
        builder.setMessage("Are you sure to exit?");  
        builder.setPositiveButton("YES", m_DlgClick);  
        builder.setNegativeButton("NO", m_DlgClick);
        builder.show(); 
	}
	
	public void Alert(String sTitle, String sMsg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);  
        builder.setTitle(sTitle);  
        builder.setMessage(sMsg);  
        builder.setPositiveButton("OK", null);
        builder.show();
	}

	private void LiveStop() {
		if (m_Wnd != null) {
			m_Live.Stop();
			m_Live.WndDestroy();
			m_Wnd = null;
			m_Live.Clean();
		}
	}
	
	private android.view.View.OnClickListener m_OnClink = new android.view.View.OnClickListener() {
		// Control clicked
		public void onClick(View args0) {
			switch (args0.getId()) {
			case R.id.btnStart:
				m_sDevID = m_editDevID.getText().toString();
				m_Live.Start(m_sDevID);
				m_Live.VideoStart();
				m_Live.AudioStart();
				break;

			case R.id.btnStop:
				m_Live.AudioStop();
				m_Live.VideoStop();
				m_Live.Stop();
				break;

			case R.id.btnCamera:
				m_Live.VideoCamera("/sdcard/Download/liverender.jpg");
				break;

			case R.id.btnScan:
				m_Live.LanScanStart();
				break;

			case R.id.btnViewWhole:
				m_Live.VideoShowMode(1);
				break;

			case R.id.btnViewCut:
				m_Live.VideoShowMode(0);
				break;

			default:
				break;
			}
		}
	};

	public pgDevVideoOut.OnCallback m_oVideoOutCB = new pgDevVideoOut.OnCallback() {

		@Override
		public int Open(int iDevNO) {
			// TODO Auto-generated method stub
			Log.d("RenExter", "pgDevVideoOut.Open: iDevNO=" + iDevNO);
			
			return 1234;
		}

		@Override
		public void Close(int iDevID) {
			// TODO Auto-generated method stub
			Log.d("RenExter", "pgDevVideoOut.Close: iDevID=" + iDevID);
		}

		@Override
		public void Image(int iDevID, byte[] byData, int iFormat, int iFlag,
			int iPosX, int iPosY, int iWidth, int iHeight, int iFillMode, int iRotate)
		{
			// TODO Auto-generated method stub
			if (iFormat == pgDevVideoOut.PG_DEV_VIDEO_OUT_FMT_RGB24) {
				m_wndPlay.DrawBitmap(byData, iPosX, iPosY, iWidth, iHeight, iFillMode);
			}
			else {
				// Need to decode data, and then play.
			}
		}

		@Override
		public void Clean(int iDevID) {
			// TODO Auto-generated method stub
			Log.d("RenExter", "pgDevVideoOut.Clean: iDevID=" + iDevID);

			m_wndPlay.DrawClean();
		}
	};
}


class VideoPlayView extends SurfaceView implements SurfaceHolder.Callback
{
	// Videp bitmap mode
	private static final int VIDEO_BITMAP_DstInSrc = 0;
	private static final int VIDEO_BITMAP_SrcInDst = 1;
	private static final int VIDEO_BITMAP_SrcFitDst = 2;

	// Board member.
	private int m_iWndWidth = 0;
	private int m_iWndHeight = 0;
	
	private int m_iWidth = 0;
	private int m_iHeight = 0;
	int[] m_iImgData = null;

	private int m_iVideoFillMode = 0;
	private int m_iVideoFillCount = 0;
	private Paint m_PaintVideo = null; 

	public VideoPlayView(Context ctx) {
		super(ctx);

		try {
			m_PaintVideo = new Paint();
			m_PaintVideo.setAntiAlias(true);
			m_PaintVideo.setFilterBitmap(true);
	
			SurfaceHolder holder = getHolder();
			holder.addCallback(this);
	
			setFocusable(true);
		}
		catch (Exception ex) {
			Log.d("pgnpp", "pgSysWnd: ex=" + ex.toString());
		}
	}
	
	public void DrawBitmap(byte[] byData, int iPosX, int iPosY, int iWidth, int iHeight, int iFillMode) {

		SurfaceHolder holder = getHolder();
		Canvas canvas = holder.lockCanvas();
		if (canvas == null) {
			return;
		}
		
		try {
			
			int iSizeXY = iWidth * iHeight;
			if (iWidth != m_iWidth || iHeight != m_iHeight) {
				m_iImgData = new int[iSizeXY];
				m_iWidth = iWidth;
				m_iHeight = iHeight;
				m_iVideoFillCount = 4;
			}
			
			int iPos = 0;
			for (int i = 0; i < iSizeXY; i++, iPos += 3) {
				m_iImgData[i] = (((byData[iPos] << 16) & 0x00ff0000)
					| ((byData[iPos + 1] << 8) & 0x0000ff00)
					| ((byData[iPos + 2]) & 0x000000ff));
			}

			int iPosX1 = 0, iPosY1 = 0;
			float fScaleX = 0.0f, fScaleY = 0.0f;

			if (m_iVideoFillMode != iFillMode) {
				m_iVideoFillMode = iFillMode;
				m_iVideoFillCount = 4;
			}
			if (m_iVideoFillCount > 0) {
				canvas.drawColor(Color.BLACK);			
				m_iVideoFillCount--;
			}

			if (iFillMode == VIDEO_BITMAP_DstInSrc) {
				if (((m_iWndWidth << 3) / m_iWndHeight) > ((iWidth << 3) / iHeight)) {
					fScaleX = (float)m_iWndWidth / (float)iWidth;
					fScaleY = fScaleX;
					int iHeight1 = (int)(((float)iWidth * (float)m_iWndHeight) / (float)m_iWndWidth);
					iPosY1 = -((iHeight - iHeight1) / 2);
				}
				else if (((m_iWndWidth << 3) / m_iWndHeight) < ((iWidth << 3) / iHeight)) {
					fScaleY = (float)m_iWndHeight / (float)iHeight;
					fScaleX = fScaleY;
					int iWidth1 = (int)(((float)iHeight * (float)m_iWndWidth) / (float)m_iWndHeight);
					iPosX1 = -((iWidth - iWidth1) / 2);
				}
				else {
					fScaleX = (float)m_iWndWidth / (float)iWidth;
					fScaleY = (float)m_iWndHeight / (float)iHeight;
				}
			}
			else if (iFillMode == VIDEO_BITMAP_SrcInDst) {
				if (((m_iWndWidth << 3) / m_iWndHeight) > ((iWidth << 3) / iHeight)) {
					fScaleX = (float)m_iWndHeight / (float)iHeight;
					fScaleY = fScaleX;
					int iWidth1 = (int)(((float)iHeight * (float)m_iWndWidth) / (float)m_iWndHeight);
					iPosX1 = (iWidth1 - iWidth) / 2;
				}
				else if (((m_iWndWidth << 3) / m_iWndHeight) < ((iWidth << 3) / iHeight)) {
					fScaleY = (float)m_iWndWidth / (float)iWidth;
					fScaleX = fScaleY;
					int iHeight1 = (int)(((float)iWidth * (float)m_iWndHeight) / (float)m_iWndWidth);
					iPosY1 = (iHeight1 - iHeight) / 2;
				}
				else {
					fScaleX = (float)m_iWndWidth / (float)iWidth;
					fScaleY = (float)m_iWndHeight / (float)iHeight;
				}
			}
			else { // (iFillMode == VIDEO_BITMAP_SrcFitDst)
				fScaleX = (float)m_iWndWidth / (float)iWidth;
				fScaleY = (float)m_iWndHeight / (float)iHeight;
			}
			
			canvas.scale(fScaleX, fScaleY);
			canvas.drawBitmap(m_iImgData, 0, iWidth, iPosX1, iPosY1, iWidth, iHeight, false, m_PaintVideo);
		}
		catch (Exception ex) {
			Log.d("pgLive", "DrawBitmap: ex=" + ex.toString());
		}

		holder.unlockCanvasAndPost(canvas);
	}

	public void DrawClean() {

		SurfaceHolder holder = getHolder();
		Canvas canvas = holder.lockCanvas();
		if (canvas == null) {
			return;
		}

		try {
			canvas.drawColor(Color.BLACK);
		}
		catch (Exception ex) {
			Log.d("pgLive", "DrawClean: ex=" + ex.toString());
		}

		holder.unlockCanvasAndPost(canvas);		
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
	}
	
	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
		m_iWndWidth = width;
		m_iWndHeight = height;
	}
	
	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
	}
}


class VideoPlayViewGL extends GLSurfaceView {

	private int m_iWidth = 0;
	private int m_iHeight = 0;

	private MyRenderer m_Renderer = null;

	public VideoPlayViewGL(Context ctx) {
		super(ctx);

		Log.d("pgLiveRenExter", "VideoPlayViewGL.VideoPlayViewGL");

		this.setFocusableInTouchMode(true);

		this.setEGLContextClientVersion(2);

		this.setEGLConfigChooser(8, 8, 8, 8, 0, 0);
		this.setDebugFlags(DEBUG_CHECK_GL_ERROR);
		
		m_Renderer = new MyRenderer();
		this.setRenderer(m_Renderer);
		this.setRenderMode(RENDERMODE_WHEN_DIRTY);
		

		Log.d("pgLiveRenExter", "VideoPlayViewGL.VideoPlayViewGL end");
	}
	
	public void DrawBitmap(byte[] byData, int iPosX, int iPosY, int iWidth, int iHeight, int iFillMode) {
		m_Renderer.DrawBitmap(byData, iPosX, iPosY, iWidth, iHeight, iFillMode);
		requestRender();
	}

	public void DrawClean() {
		m_Renderer.DrawClean();
		requestRender();
	}
}


///-------------------------------------------------------------------------------------
// Renderer.
class MyRenderer implements GLSurfaceView.Renderer { 

	// Videp bitmap mode
	private static final int VIDEO_BITMAP_DstInSrc = 0;
	private static final int VIDEO_BITMAP_SrcInDst = 1;
	private static final int VIDEO_BITMAP_SrcFitDst = 2;

	// Board member.
	private int m_iWndWidth = 0;
	private int m_iWndHeight = 0;
	
	private int m_iVideoFillMode = 0;
	private int m_iVideoFillCount = 0;

	private int m_iTexture = -1;

	private Object m_sDraw = new Object();
	private ByteBuffer m_byBuf = null;
	private int m_iDrawPosX = 0;
	private int m_iDrawPosY = 0;
	private int m_iDrawWidth = 0;
	private int m_iDrawHeight = 0;
	private int m_iDrawFillMode = 0;

	public MyRenderer() {
		super();
		Log.d("pgLiveRenExter", "MyRenderer.MyRenderer");
	}
	
	public void DrawBitmap(byte[] byData, int iPosX, int iPosY, int iWidth, int iHeight, int iFillMode) {
		try {
			synchronized(m_sDraw) {
				m_byBuf = ByteBuffer.wrap(byData);
				m_iDrawPosX = iPosX;
				m_iDrawPosY = iPosY;
				m_iDrawWidth = iWidth;
				m_iDrawHeight = iHeight;
				m_iDrawFillMode = iFillMode;
			}
		}
		catch (Exception ex) {
			Log.d("pgLiveRenExter", "MyRenderer.DrawBitmap, ex=" + ex.toString());			
		}
	}
	
	public void DrawClean() {
		try {
			synchronized(m_sDraw) {
				m_byBuf = null;
			}
		}
		catch (Exception ex) {
			Log.d("pgLiveRenExter", "MyRenderer.DrawClean, ex=" + ex.toString());			
		}		
	}

	@Override
	public void onDrawFrame(javax.microedition.khronos.opengles.GL10 gl) {
		
		try {
			synchronized(m_sDraw) {

				int iErr;
				if (m_byBuf != null) {
					if (m_iTexture < 0) {
						int iTexture[] = new int[1];
						GLES20.glGenTextures(1, iTexture, 0);
						if ((iErr = GLES20.glGetError()) != GLES20.GL_NO_ERROR) {
							Log.d("pgLiveRenExter", "MyRenderer.onDrawFrame: glGenTextures, iErr=" + iErr);
						}
						m_iTexture = iTexture[0];
						Log.d("pgLiveRenExter", "MyRenderer.onDrawFrame, m_iTexture=" + m_iTexture);

					}

					GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
					if ((iErr = GLES20.glGetError()) != GLES20.GL_NO_ERROR) {
						Log.d("pgLiveRenExter", "MyRenderer.onDrawFrame: glClear, iErr=" + iErr);
					}			

					GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, m_iTexture);
					if ((iErr = GLES20.glGetError()) != GLES20.GL_NO_ERROR) {
						Log.d("pgLiveRenExter", "MyRenderer.onDrawFrame: glBindTexture, iErr=" + iErr);
					}

					GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST);  
					GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);  
					GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);  
					GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
					if ((iErr = GLES20.glGetError()) != GLES20.GL_NO_ERROR) {
						Log.d("pgLiveRenExter", "MyRenderer.onDrawFrame: glTexParameteri, iErr=" + iErr);
					}
					
					GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGB, 256,
						256, 0, GLES20.GL_RGB, GLES20.GL_UNSIGNED_BYTE, m_byBuf);
					if ((iErr = GLES20.glGetError()) != GLES20.GL_NO_ERROR) {
						Log.d("pgLiveRenExter", "MyRenderer.onDrawFrame: glTexImage2D, iErr=" + iErr);
					}
					
					Log.d("pgLiveRenExter", "MyRenderer.onDrawFrame draw, datasize=" + m_byBuf.limit());
				}
				else {
					GLES20.glClearColor(0.0f, 0.0f, 1.0f, 1.0f);  
					if ((iErr = GLES20.glGetError()) != GLES20.GL_NO_ERROR) {
						Log.d("pgLiveRenExter", "MyRenderer.onDrawFrame: glClearColor, iErr=" + iErr);
					}

					GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);

					Log.d("pgLiveRenExter", "MyRenderer.onDrawFrame clear");
				}
			}
		}
		catch (Exception ex) {
			Log.d("pgLiveRenExter", "MyRenderer.onDrawFrame, ex=" + ex.toString());
		}
	}

	@Override
	public void onSurfaceChanged(javax.microedition.khronos.opengles.GL10 gl, int width, int height) {
		Log.d("pgLiveRenExter", "MyRenderer.onSurfaceChanged");

		int iErr;

		GLES20.glViewport(0, 0, width, height);
		if ((iErr = GLES20.glGetError()) != GLES20.GL_NO_ERROR) {
			Log.d("pgLiveRenExter", "MyRenderer.onSurfaceChanged: glViewport, iErr=" + iErr);
		}

		m_iWndWidth = width;
		m_iWndHeight = height;
	}

	@Override
	public void onSurfaceCreated(javax.microedition.khronos.opengles.GL10 arg0,
		javax.microedition.khronos.egl.EGLConfig arg1)
	{
		// TODO Auto-generated method stub
		Log.d("pgLiveRenExter", "MyRenderer.onSurfaceCreated");

		int iErr;

		GLES20.glEnable(GLES20.GL_TEXTURE_2D); 
		if ((iErr = GLES20.glGetError()) != GLES20.GL_NO_ERROR) {
			Log.d("pgLiveRenExter", "MyRenderer.onSurfaceCreated: glEnable, iErr=" + iErr);
		}

		// Active the texture unit 0 
		GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
		if ((iErr = GLES20.glGetError()) != GLES20.GL_NO_ERROR) {
			Log.d("pgLiveRenExter", "MyRenderer.onSurfaceCreated: glActiveTexture, iErr=" + iErr);
		}
	} 
}


