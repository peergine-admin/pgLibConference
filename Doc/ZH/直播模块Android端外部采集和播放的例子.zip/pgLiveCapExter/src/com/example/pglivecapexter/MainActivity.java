package com.example.pglivecapexter;

import java.nio.ByteBuffer;
import java.util.List;

import com.peergine.android.live.pgLibLive;
import com.peergine.android.live.pgLibLiveMode;
import com.peergine.plugin.android.pgDevAudioIn;
import com.peergine.plugin.android.pgDevVideoIn;
import com.peergine.plugin.lib.pgLibJNINode;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.graphics.ImageFormat;
import android.graphics.PixelFormat;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;

public class MainActivity extends Activity {

	private android.widget.EditText m_editDevID;
	private android.widget.Button m_btnStart;
	private android.widget.Button m_btnStop;

	String m_sDevID = "";
	pgLibLive m_Live = new pgLibLive();
	LinearLayout m_View = null;
	SurfaceView m_Wnd = null;
	CameraView m_CameraView = null;
	ExterAudioIn m_AudioIn = null;

	private boolean m_bScreenON = true;
	
	private Handler m_hander = new Handler() {
		public void handleMessage(Message msg) {  
			if (msg.what == 0) {
				if (m_bScreenON) {
					m_Live.ServerNetMode(0);
				}
			}
			else if (msg.what == 2) {
				if (!m_bScreenON) {
					m_Live.ServerNetMode(2);
				}
			}
		}
	};

	private BroadcastReceiver m_BroadcastReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
    	   String sAct = intent.getAction();
    	   if (sAct.equals(Intent.ACTION_SCREEN_ON)) {
    		   m_bScreenON = true;
     		   m_hander.sendEmptyMessage(0);
    	   }
    	   else if (sAct.equals(Intent.ACTION_SCREEN_OFF)) {
    		   m_bScreenON = false;
     		   m_hander.sendEmptyMessageDelayed(2, (15 * 1000));
    	   }
		}
	};

	private void ReceiveRegister() {
		IntentFilter intentFilterScnOn = new IntentFilter(Intent.ACTION_SCREEN_ON);
		IntentFilter intentFilterScnOff = new IntentFilter(Intent.ACTION_SCREEN_OFF);
		registerReceiver(m_BroadcastReceiver, intentFilterScnOn);		
		registerReceiver(m_BroadcastReceiver, intentFilterScnOff);		
	}

	private void ReceiveUnregister() {
		unregisterReceiver(m_BroadcastReceiver);
	}

	private pgLibLive.OnEventListener m_OnEvent = new pgLibLive.OnEventListener() {

		@Override
		public void event(String sAct, String sData, String sRender) {
			// TODO Auto-generated method stub

			if (sAct.equals("VideoStatus")) {
				// Video status report
			}
			else if (sAct.equals("Notify")) {
				// Receive the notify from capture side
				String sInfo = "Receive notify: data=" + sData;
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();			
			}
			else if (sAct.equals("RenderJoin")) {
				// A render join
				String sInfo = "Render join: render=" + sRender;
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();			
			}
			else if (sAct.equals("RenderLeave")) {
				// A render leave
				String sInfo = "Render leave: render=" + sRender;
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();			
			}
			else if (sAct.equals("Message")) {
				// Receive the message from render or capture
				String sInfo = "Receive msg: data=" + sData + ", render=" + sRender;
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();			
			}
			else if (sAct.equals("Login")) {
				// Login reply
				if (sData.equals("0")) {
					String sInfo = "Login success";
					Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
				}
				else {
					String sInfo = "Login failed, error=" + sData;
					Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();					
				}
			}
			else if (sAct.equals("Logout")) {
				// Logout
				String sInfo = "Logout";
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
			}
			else if (sAct.equals("Connect")) {
				// Connect to capture
				String sInfo = "Connect to capture";
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
			}
			else if (sAct.equals("Disconnect")) {
				// Disconnect from capture
				String sInfo = "Diconnect from capture";
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
			}
			else if (sAct.equals("Offline")) {
				// The capture is offline.
				String sInfo = "Capture offline";
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
			}
			else if (sAct.equals("LanScanResult")) {
				// Lan scan result.
				String sInfo = "Lan scan result: " + sData;
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
			}
			else if (sAct.equals("ForwardAllocReply")) {
				String sInfo = "Forward alloc relpy: error=" + sData;
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
			}
			else if (sAct.equals("ForwardFreeReply")) {
				String sInfo = "Forward free relpy: error=" + sData;
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
			} 
			else if (sAct.equals("VideoCamera")) {
				String sInfo = "The picture is save to: " + sData;
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
			}
			else if (sAct.equals("SvrNotify")) {
				String sInfo = "Receive server notify: " + sData;
				Toast.makeText(MainActivity.this, sInfo, Toast.LENGTH_SHORT).show();
			}
			
			Log.d("pgLiveCapExter", "OnEvent: Act=" + sAct + ", Data=" + sData + ", Render=" + sRender);
		}
	};

	private boolean CheckPlugin() {
		if (pgLibJNINode.Initialize(this)) {
			pgLibJNINode.Clean();
			return true;
		}
		else {
			Alert("Error", "Please import 'pgPluginLib' peergine middle ware!");
			return false;
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
				WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

		m_editDevID = (android.widget.EditText)findViewById(R.id.editDevID);
		m_btnStart = (android.widget.Button)findViewById(R.id.btnStart);
		m_btnStart.setOnClickListener(m_OnClink);
		m_btnStop = (android.widget.Button)findViewById(R.id.btnStop);
		m_btnStop.setOnClickListener(m_OnClink);
		
		if (!CheckPlugin()) {
			return;
		}
		
		m_Live.SetEventListener(m_OnEvent);
		
		ReceiveRegister();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	public void onDestroy() {
		super.onDestroy();
		ReceiveUnregister();
		LiveStop();
	}

	public boolean onKeyUp(int keyCode, KeyEvent event) {
	    if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			Log.d("pgLiveCapExter", "onKeyDown, KEYCODE_BACK");
	      	ExitDialog();
      		return true;
	    }
	    return super.onKeyUp(keyCode, event);
	}

	private DialogInterface.OnClickListener m_DlgClick = new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int which) {
        	if (which == AlertDialog.BUTTON_POSITIVE) {
        		LiveStop();
        		android.os.Process.killProcess(android.os.Process.myPid());  
        	}
        }
    };
	public void ExitDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);  
        builder.setTitle("Confirm");  
        builder.setMessage("Are you sure to exit?");  
        builder.setPositiveButton("YES", m_DlgClick);  
        builder.setNegativeButton("NO", m_DlgClick);
        builder.show(); 
	}

	public void Alert(String sTitle, String sMsg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);  
        builder.setTitle(sTitle);  
        builder.setMessage(sMsg);  
        builder.setPositiveButton("OK", null);
        builder.show();
	}

	private void LiveStart() {
		if (m_Wnd != null) {
			return;
		}
		
		// Camera facing.
		// CameraInfo.CAMERA_FACING_FRONT or CameraInfo.CAMERA_FACING_BACK
		int iCameraNo = CameraInfo.CAMERA_FACING_FRONT;

		// (VideoInExternal){1}, Use the extend video input interface.
		m_sDevID = m_editDevID.getText().toString();
		if (!m_Live.Initialize(pgLibLiveMode.Capture, m_sDevID, "", "connect.peergine.com:7781",
			"", 3, "(Code){3}(Mode){2}(Rate){30}(CameraNo){" + iCameraNo + "}(InputExternal){1}", this))
		{
			Log.d("pgLiveCapExter", "LiveStart: Live.Initialize failed!");
			Alert("Error", "Network error, DNS Resolution failed!");
			return;
		}
		
		pgDevVideoIn.SetCallback(m_oVideoInCB);
		pgDevAudioIn.SetCallback(m_oAudioInCB);
		SetAudioInExter();
		Log.d("pgLiveCapExter", "LiveStart: Set callback");
		
		// Portrait video.
		if (iCameraNo == CameraInfo.CAMERA_FACING_BACK) {
			SetVideoRotate(90);
		}
		else {
			SetVideoRotate(270);
		}

		m_Wnd = (SurfaceView)m_Live.WndCreate(0, 0, 320, 240);
		Log.d("pgLiveCapExter", "LiveStart: create plugin wnd");
		
		m_View = (LinearLayout)findViewById(R.id.layoutVideo);;

		m_CameraView = new CameraView(this);
		m_View.addView(m_CameraView);
		m_CameraView.setVisibility(View.GONE);
		Log.d("pgLiveCapExter", "LiveStart: new camera view");

		m_CameraView.Initialize();
		Log.d("pgLiveCapExter", "LiveStart: initialize capture");
		
		m_AudioIn = new ExterAudioIn();
		Log.d("pgLiveCapExter", "LiveStart: new exter audio in");

		m_Live.Start(m_sDevID);	
		Log.d("pgLiveCapExter", "LiveStart: start.");
	}
	
	private void LiveStop() {
		if (m_Wnd != null) {
			m_Live.Stop();
			m_CameraView.Clean();

			m_View.removeView(m_CameraView);
			m_CameraView = null;

			m_Live.WndDestroy();
			m_View = null;
			m_Wnd = null;

			pgDevVideoIn.SetCallback(null);
			pgDevAudioIn.SetCallback(null);
			m_Live.Clean();
		}
	}

	private void SetVideoRotate(int iAngle) {
		pgLibJNINode Node = m_Live.GetNode();
		if (Node != null) {
			if (Node.ObjectAdd("_vTemp", "PG_CLASS_Video", "", 0)) {
				Node.ObjectRequest("_vTemp", 2, "(Item){2}(Value){" + iAngle + "}", "");
				Node.ObjectDelete("_vTemp");
			}
		}
	}
	
	private android.view.View.OnClickListener m_OnClink = new android.view.View.OnClickListener() {
		// Control clicked
		public void onClick(View args0) {
			switch (args0.getId()) {
			case R.id.btnStart:
				LiveStart();
				m_Live.VideoStart();
				m_Live.AudioStart();
				break;

			case R.id.btnStop:
				m_Live.AudioStop();
				m_Live.VideoStop();
				LiveStop();
				break;
			default:
				break;
			}
		}
	};

	public pgDevVideoIn.OnCallback m_oVideoInCB = new pgDevVideoIn.OnCallback() {

		@Override
		public int Open(int iDevNO, int iPixBytes, int iWidth, int iHeight,
			int iBitRate, int iFrmRate, int iKeyFrmRate)
		{
			// TODO Auto-generated method stub
		//	if (iWidth != 320 || iHeight != 240) {
		//		return -1;
		//	}

			// The iDevID is '1234'.
			int iDevID = 1234;
			if (!m_CameraView.Start(iDevID, iDevNO, iWidth, iHeight, iFrmRate)) {
				return -1;
			}
	
			return iDevID; 
		}

		@Override
		public void Close(int iDevID) {
			// TODO Auto-generated method stub

			m_CameraView.Stop();
			Log.d("pgLiveCapExter", "pgDevVideoIn.OnCallback.Open: run close");
		}

		@Override
		public void Ctrl(int iDevID, int iCtrl, int iParam) {
			// TODO Auto-generated method stub

			m_CameraView.Ctrl(iDevID, iCtrl, iParam);
		}
	};

	public pgDevAudioIn.OnCallback m_oAudioInCB = new pgDevAudioIn.OnCallback() {
		
		@Override
		public int Open(int iDevNO, int iSampleBits, int iSampleRate, int iChannels, int iPackBytes) {
			// TODO Auto-generated method stub
			
			// The iDevID is '1234'.
			m_AudioIn.Open(1234, iSampleBits, iSampleRate, iChannels, iPackBytes, iDevNO);
			return 1234; 
		}

		@Override
		public void Close(int iDevID) {
			// TODO Auto-generated method stub

			m_AudioIn.Close();
			Log.d("pgLiveCapExter", "pgDevAudioIn.OnCallback.Close");
		}
	};

	private void SetAudioInExter() {
		pgLibJNINode Node = m_Live.GetNode();
		if (Node != null) {
			if (Node.ObjectAdd("_aTemp", "PG_CLASS_Audio", "", 0)) {
				Node.ObjectRequest("_aTemp", 2, "(Item){4}(Value){1}", "");
				Node.ObjectDelete("_aTemp");
			}
		}
	}
}


class CameraView extends SurfaceView implements SurfaceHolder.Callback, Camera.PreviewCallback
{
	private static final boolean HW_CODEC = false;
	
	private Handler m_Handler = null;

	private Camera m_Camera = null;
	private SurfaceHolder m_Holder; 
	
	private int m_iCameraWidth = 0;
	private int m_iCameraHeight = 0;
	private int m_iCameraFrmRate = 0;
	
	private MediaCodec m_MediaCodec = null;
	private int m_iDevID = -1;
	private int m_iCameraNo = -1;
	private int m_iCameraFormat = -1;
	
	private int m_iCameraOpenStatus = -1;
	private int m_iCameraCloseStatus = -1;

	public CameraView(Context ctx) {
		super(ctx);
	}
	
	public boolean Initialize() {
		try {
			Log.d("pgLiveCapExter", "CameraView.Initialize");

			m_Handler = new Handler() {
				public void handleMessage(Message msg) {
					try {
					}
					catch (Exception ex) {
						Log.d("pgLiveCapExter", "handleMessage Exception");
					}
				}
			};
			
			m_Holder = getHolder();
			m_Holder.addCallback(this);

			return true;
		}
		catch (Exception ex) {
			Log.d("pgLiveCapExter", "CameraView.Start, ex=" + ex.toString());

			return false;
		}
	}
	
	public void Clean() {
		try {
			Log.d("pgLiveCapExter", "CameraView.Clean");
			
			Stop();
		}
		catch (Exception ex) {
			Log.d("pgLiveCapExter", "CameraView.Clean, ex=" + ex.toString());
		}
	}

	public boolean Start(int iDevID, int iCameraNo, int iW, int iH, int iFrmRate) {
		try {
			Log.d("pgLiveCapExter", "CameraView.Start: iW=" + iW + ", iH=" + iH + ", iFrmRate=" + iFrmRate);

			m_iDevID = iDevID;
			m_iCameraNo = iCameraNo;
			m_iCameraWidth = iW;
			m_iCameraHeight = iH;
			m_iCameraFrmRate = iFrmRate;

			if (HW_CODEC) {
				m_MediaCodec = MediaCodec.createEncoderByType("video/avc");
	
				MediaFormat mediaFormat = MediaFormat.createVideoFormat("video/avc", m_iCameraWidth, m_iCameraHeight);
				mediaFormat.setInteger(MediaFormat.KEY_BIT_RATE, 512000);
				mediaFormat.setInteger(MediaFormat.KEY_FRAME_RATE, (1000 / iFrmRate));
				mediaFormat.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar);
				mediaFormat.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 3);
	
				m_MediaCodec.configure(mediaFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
				m_MediaCodec.start();
			}

			// Reset the open status.
			m_iCameraOpenStatus = -1;

			// Post the open camera handle to UI thread.
			m_Handler.post(new Runnable() {
				public void run() {
					Log.d("pgLiveCapExter", "CameraView.Start, run PreviewOpen");
					PreviewOpen();
				}
			});
			
			// wait and check the open result
			int i = 0;
			while (i < 20) {
				if (m_iCameraOpenStatus >= 0) {
					break;
				}
				Thread.sleep(100);
				i++;
			}
			if (m_iCameraOpenStatus <= 0) {
				return false;
			}
			
			return true;
		}
		catch (Exception ex) {
			Log.d("pgLiveCapExter", "CameraView.Start, ex=" + ex.toString());
			return false;
		}
	}
	
	public void Ctrl(int iDevID, int iCtrl, int iParam) {
		if (iDevID != m_iDevID) {
			return;
		}
		
		if (iCtrl == pgDevVideoIn.PG_DEV_VIDEO_IN_CTRL_PULL_KEY_FRAME) {

			// *** Important: Let's the encoder to output a key frame immidiately.
			// Add code here ...

			if (HW_CODEC) {
				
			}
		}		
	}

	public void Stop() {
		try {
			Log.d("pgLiveCapExter", "CameraView.Stop");

			// Reset the close status.
			m_iCameraCloseStatus = -1;

			// Post the close camera handle to UI thread.
			m_Handler.post(new Runnable() {
				public void run() {
					Log.d("pgLiveCapExter", "CameraView.Stop, run PreviewClose");
					PreviewClose();
				}
			});

			// wait and check the close result
			int i = 0;
			while (i < 5) {
				if (m_iCameraCloseStatus >= 0) {
					break;
				}
				Thread.sleep(100);
				i++;
			}

			if (HW_CODEC) {
	 			if (m_MediaCodec != null) {
	 				m_MediaCodec.stop();
					m_MediaCodec.release();
					m_MediaCodec = null;
				}
			}
		}
		catch (Exception ex) {
			Log.d("pgLiveCapExter", "CameraView.Stop, ex=" + ex.toString());
		}
	}
	
	public void PreviewOpen() {
		try {
			Log.d("pgLiveCapExter", "CameraView.PreviewOpen");
			
			getHolder().setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		
			if (getVisibility() != View.GONE) {
				setVisibility(View.GONE);
			}
			setVisibility(View.VISIBLE);
		}
		catch (Exception ex) {
			Log.d("pgLiveCapExter", "CameraView.PreviewOpen, ex=" + ex.toString());
		}
	}
	
	public void PreviewClose() {
		try {
			Log.d("pgLiveCapExter", "CameraView.PreviewClose");
			if (m_Camera != null) {
				if (getVisibility() != View.GONE) {
					setVisibility(View.GONE);
				}
				getHolder().setType(SurfaceHolder.SURFACE_TYPE_NORMAL);
				m_Camera = null;
			}
		}
		catch (Exception ex) {
			Log.d("pgLiveCapExter", "CameraView.PreviewClose, ex=" + ex.toString());
		}
	}
	
    public void surfaceCreated(SurfaceHolder surfaceholder) {
		Log.d("pgLiveCapExter", "CameraView.surfaceCreated");
	} 

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
		// TODO Auto-generated method stub
		try { 
			if (m_Camera == null) {

				int iCameraInd = -1;
				int iCameraIndFront = -1;
				Camera cameraTemp = null;
				
				for (int iInd = 0; iInd < Camera.getNumberOfCameras(); iInd++) {
					CameraInfo info = new CameraInfo();
					Camera.getCameraInfo(iInd, info);
					if (info.facing == m_iCameraNo) {
						iCameraInd = iInd;
						Log.d("pgLiveCapExter", "CameraView.surfaceChanged: Select iCameraNo=" + m_iCameraNo);
						break;
					}
					if (iCameraIndFront < 0 && info.facing == CameraInfo.CAMERA_FACING_FRONT) {
						iCameraIndFront = iInd;
					}
				}
	
				// If not 'iCameraNo' camera, select front camera.
				if (iCameraInd < 0 && iCameraIndFront >= 0) {
					iCameraInd = iCameraIndFront;
					Log.d("pgLiveCapExter", "CameraView.surfaceChanged: Select front camera.");
				}
	
				// Try to open the selected camera.
				if (iCameraInd >= 0) {
					cameraTemp = Camera.open(iCameraInd);
				}
	
				if (cameraTemp == null) {
					cameraTemp = Camera.open(0);
					if (cameraTemp == null) {
						Log.d("pgLiveCapExter", "CameraView.surfaceChanged, open camera failed.");
						return;
					}
				}
				
				m_Camera = cameraTemp;
			}
			else {
				m_Camera.stopPreview();
			}
	
			// Check support size.
			boolean bHasSizeMode = false;
			Camera.Parameters Param = m_Camera.getParameters();
			List<Camera.Size> sizeList = Param.getSupportedPreviewSizes();
			for (int i = 0; i < sizeList.size(); i++) {
				Camera.Size size = sizeList.get(i);
				if (size.width == m_iCameraWidth && size.height == m_iCameraHeight) {
					bHasSizeMode = true;
					break;
				}
				Log.d("pgLiveCapExter", "CameraView.surfaceChanged: Not match size: width=" + size.width + ", height=" + size.height);
			}
			if (!bHasSizeMode) {
				Log.d("pgLiveCapExter", "CameraView.surfaceChanged: Not find valid size mode");
				m_iCameraOpenStatus = 0;
				return;
			}

			// Set preview size
			Param.setPreviewSize(m_iCameraWidth, m_iCameraHeight);

			// List all preview format.
			List<Integer> fmtList = Param.getSupportedPreviewFormats();
			for (int i = 0; i < fmtList.size(); i++) {
				Log.d("pgLiveCapExter", "CameraView.surfaceChanged: Format=" + fmtList.get(i));
			}
			
			// Select an support format.
			int iFmtSel = -1;
			int[] iFmtList = new int[]{ImageFormat.NV21,
				ImageFormat.NV16, ImageFormat.YUY2, ImageFormat.YV12};
			for (int i = 0; i < iFmtList.length; i++) {
				for (int j = 0; j < fmtList.size(); j++) {
					if (iFmtList[i] == fmtList.get(j)) {
						iFmtSel = iFmtList[i];
						break;
					}
				}
				if (iFmtSel >= 0) {
					break;
				}
			}
			if (iFmtSel < 0) {
				m_iCameraOpenStatus = 0;
				return;
			}

			Log.d("pgLiveCapExter", "CameraView.surfaceChanged: Format=, iFmtSel=" + iFmtSel);
			Param.setPreviewFormat(iFmtSel);

			switch(iFmtSel) {
			case ImageFormat.NV16:
				m_iCameraFormat = pgDevVideoIn.PG_DEV_VIDEO_IN_FMT_YUV422SP;
				break;
			case ImageFormat.NV21:
				m_iCameraFormat = pgDevVideoIn.PG_DEV_VIDEO_IN_FMT_YUV420SP;
				break;
			case ImageFormat.YUY2:
				m_iCameraFormat = pgDevVideoIn.PG_DEV_VIDEO_IN_FMT_YUYV;
				break;
			case ImageFormat.YV12:
				m_iCameraFormat = pgDevVideoIn.PG_DEV_VIDEO_IN_FMT_YV12;
				break;
			}
			
			// Set preview frame rates.
			int iRateInput = (1000 / m_iCameraFrmRate);
			int iRateSet = iRateInput;

			int iDeltaMin = 65536;
			List<Integer> listRate = m_Camera.getParameters().getSupportedPreviewFrameRates();
			for (int i = 0; i < listRate.size(); i++) {
				int iRateTemp = listRate.get(i);
				int iDeltaTemp = iRateTemp - iRateInput;
				if (iDeltaTemp < 0) {
					iDeltaTemp = -iDeltaTemp;
				}
				if (iDeltaTemp < iDeltaMin) {
					iDeltaMin = iDeltaTemp;
					iRateSet = iRateTemp;
				}
				Log.d("pgLiveCapExter", "CameraView.surfaceChanged: Rate=" + iRateTemp);
			}
			
			Log.d("pgLiveCapExter", "CameraView.surfaceChanged: Param.setPreviewFrameRate, iRateSet=" + iRateSet);
			Param.setPreviewFrameRate(iRateSet);

			// Set rotate 90
			Param.set("rotation", 90);
			m_Camera.setDisplayOrientation(90);

			m_Camera.setParameters(Param); 

			m_Camera.setPreviewCallback(this);
			m_Camera.setPreviewDisplay(m_Holder);

			m_Camera.startPreview();
			
			// Start success.
			m_iCameraOpenStatus = 1;

			Log.d("pgLiveCapExter", "CameraView.surfaceChanged, startPreview.");
		} 
		catch (Exception ex) { 
			m_Camera.setPreviewCallback(null) ;
			m_Camera.stopPreview();
			m_Camera.release();
			m_Camera = null;
			m_iCameraOpenStatus = 0;
			Log.d("pgLiveCapExter", "CameraView.surfaceChanged, ex=" + ex.toString());
		}
	}
  
	public void surfaceDestroyed(SurfaceHolder surfaceholder) { 
		if (m_Camera != null) { 
			try { 
				m_Camera.setPreviewCallback(null) ;
				m_Camera.stopPreview(); 
				m_Camera.release();
				m_Camera = null;
				m_iCameraCloseStatus = 1;
			}
			catch(Exception ex) { 
				m_Camera = null;
				Log.d("pgLiveCapExter", "CameraView.surfaceDestroyed, ex=" + ex.toString());
				m_iCameraCloseStatus = 0;
			}
		} 
		Log.d("pgLiveCapExter", "CameraView.surfaceDestroyed");
	}

	public void onPreviewFrame(byte[] data, Camera camera) {
		
		if (m_iDevID < 0) {
			return;
		}

		Log.d("pgLiveCapExter", "CameraView.onPreviewFrame, begin. dataSize=" + data.length);

		if (HW_CODEC) {
			// Compress with h264.	
			ByteBuffer[] inputBuffers = m_MediaCodec.getInputBuffers();
			ByteBuffer[] outputBuffers = m_MediaCodec.getOutputBuffers();
	
			int inpuIndex = m_MediaCodec.dequeueInputBuffer(-1);
			if (inpuIndex >= 0) {
				inputBuffers[inpuIndex].clear();
				inputBuffers[inpuIndex].put(data, 0, data.length);
				m_MediaCodec.queueInputBuffer(inpuIndex, 0, data.length, 0, 0);
			}
	
			MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
			int outputIndex = m_MediaCodec.dequeueOutputBuffer(bufferInfo, 0);
			while (outputIndex >= 0) {
	
				byte[] outData = new byte[bufferInfo.size];  
				outputBuffers[outputIndex].get(outData);
				
				int iFlag = 0;
				if (outData[4] == 0x67) { // The key frame. It must has a SPS head.
					iFlag |= pgDevVideoIn.PG_DEV_VIDEO_IN_FLAG_KEY_FRAME;
				}
				
				// Call peergine capture callback.
				pgDevVideoIn.CaptureProc(m_iDevID, outData, pgDevVideoIn.PG_DEV_VIDEO_IN_FMT_H264, iFlag);
				Log.d("pgLiveCapExter", "CameraView.onPreviewFrame, dataSize=" + outData.length + ", iFlag=" + iFlag);
				
				m_MediaCodec.releaseOutputBuffer(outputIndex, false);
				outputIndex = m_MediaCodec.dequeueOutputBuffer(bufferInfo, 0);
			}
		}
		else {
			// Uncompress callback.
			pgDevVideoIn.CaptureProc(m_iDevID, data, m_iCameraFormat, 0);
		}
	}
}

class ExterAudioIn {
	
	private int m_iDevID = 0;
	private AudioRecord m_Recorder = null;
	private byte[] m_byteData = null;
	private int m_iDataSize = 0;
	private boolean m_bPoll = false;

	public ExterAudioIn() {
	}

	public boolean Open(int iDevID, int uSampleBits, int uSampleRate, int uChannels, int uPackBytes, int iMicNo) {
		try {
			Log.d("pgLiveCapExter", "ExterAudioIn.Open, uSampleBits=" + uSampleBits
				+ ", uSampleRate=" + uSampleRate + ", uPackBytes=" + uPackBytes);

			m_iDevID = iDevID;

			m_byteData = new byte[uPackBytes];
			m_iDataSize = 0;

			int iSampleFmt = (uSampleBits == 16) ? AudioFormat.ENCODING_PCM_16BIT : AudioFormat.ENCODING_PCM_8BIT;
			int iMinBufSize = AudioRecord.getMinBufferSize(uSampleRate, AudioFormat.CHANNEL_IN_MONO, iSampleFmt);
			if (iMinBufSize <= 0) {
				Log.d("pgLiveCapExter", "ExterAudioIn.Open, failed, get min buffer sise");
				return false;
			}

			int iBufSize = uPackBytes * 12;
			if (iBufSize < iMinBufSize) {
				iBufSize = (iMinBufSize / uPackBytes) * uPackBytes + uPackBytes;
			}
			
			int iMicNoTemp = MediaRecorder.AudioSource.MIC;
			if (iMicNo != 0) {
				iMicNoTemp = iMicNo;
			}
			
			m_Recorder = new AudioRecord(iMicNoTemp, uSampleRate,
				AudioFormat.CHANNEL_IN_MONO, iSampleFmt, iBufSize);
			if (m_Recorder.getState() != AudioRecord.STATE_INITIALIZED) {
				Log.d("pgLiveCapExter", "ExterAudioIn.Open, failed, not inited");
				return false;
			}

			m_Recorder.startRecording();
			
			m_bPoll = true;
			m_thread = new AudioReadThread();
			m_thread.start();

			Log.d("pgLiveCapExter", "ExterAudioIn Open ok");
			return true;
		}
		catch (Exception ex) {
			Log.d("pgLiveCapExter", "ExterAudioIn.Open Exception, ex=" + ex.toString());
			m_bPoll = false;
			return false;
		}
	}

	public void Close() {
		try {
			Log.d("pgLiveCapExter", "ExterAudioIn.Close");
	
			m_bPoll = false;
			if (m_thread != null) {
				m_thread.join(500);
			}
		
			if (m_Recorder != null) {
				m_Recorder.setRecordPositionUpdateListener(null);
				m_Recorder.stop();
				m_Recorder.release();
				m_Recorder = null;
			}
		}
		catch (Exception ex) {
			Log.d("pgLiveCapExter", "ExterAudioIn.Close Exception, ex=" + ex.toString());
		}
	}
	
	public int ReadData() {
		try {
			int iRead = m_Recorder.read(m_byteData, 0, m_byteData.length);
			if (iRead > 0) {
				pgDevAudioIn.RecordProc(m_iDevID, m_byteData,
					pgDevAudioIn.PG_DEV_AUDIO_IN_FMT_PCM16, 0);
			}

			return iRead;
		}
		catch (Exception ex) {
			Log.d("pgLiveCapExter", "ExterAudioIn.ReadData Exception, ex=" + ex.toString());
			return -1;
		}
	}

	Thread m_thread = null;
	
	class AudioReadThread extends Thread {
		public void run() {
			ExterAudioIn.this.ThreadProc();
		}
	}

	public void ThreadProc() {
		try {
			android.os.Process.setThreadPriority(
				android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);

			while (true) {
				ReadData();
				if (!m_bPoll) {
					break;
				}
				Thread.sleep(10);
			}

			Log.d("pgLiveCapExter", "ExterAudioIn.ThreadProc exit");
		}
		catch (Exception ex) {
			Log.d("pgLiveCapExter", "ExterAudioIn.ThreadProc Exception, ex=" + ex.toString());
		}
	}
}
