/*************************************************************************
  copyright   : Copyright (C) 2014, chenbichao, All rights reserved.
              : www.peergine.com, www.pptun.com
              :
  filename    : pgLibLiveMode.java
  discription : 
  modify      : create, chenbichao, 2014/07/24

*************************************************************************/

package com.peergine.android.live;

public class pgLibLiveMode {
	public static final int Render = 0;
	public static final int Capture = 1;
}
